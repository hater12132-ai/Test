#pragma once

#include <string>

namespace aspectratio {

enum class Mode {
    Multiplier = 0,  // Force aspect = ratio
    Fixed      = 1   // aspect = (height/width) * ratio   (same as Java mod)
};

struct ModConfig {
    int version = 1;

    bool enabled = true;

    // 0 = Multiplier, 1 = Fixed
    int mode = 0;

    // Default 1.0 (same as the original Java mod)
    float ratio = 1.0f;
};

} // namespace aspectratio
