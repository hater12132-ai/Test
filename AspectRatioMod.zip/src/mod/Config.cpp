#include "mod/Config.h"

// This file exists so the config_generator and the mod share the same type.
// No extra logic needed.
