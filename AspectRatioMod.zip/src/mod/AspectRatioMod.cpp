#include "mod/AspectRatioMod.h"

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <string>

namespace aspectratio {

// ---------------------------------------------------------------------------
// Signature for GetPerspective (from BedrockTools, arm64)
// May need updating for future Minecraft versions.
// ---------------------------------------------------------------------------
static constexpr const char* GET_PERSPECTIVE_PATTERN =
    "? ? ? A9 FD 03 00 91 ? ? ? F9 ? ? ? F9 ? ? ? F9 00 01 3F D6 ? ? ? F9 ? ? ? F9 ? ? ? A8 20 00 1F D6 ? ? ? A9 FD 03 00 91";

using GetPerspectiveFn = float (*)(void*);

static GetPerspectiveFn g_originalGetPerspective = nullptr;
static AspectRatioMod*  g_modInstance = nullptr;
static pl::memory::HookHandle g_hookHandle;

static float hookedGetPerspective(void* self) {
    float original = 1.777778f; // safe 16:9 fallback
    if (g_originalGetPerspective) {
        original = g_originalGetPerspective(self);
    }
    if (!g_modInstance) {
        return original;
    }
    return g_modInstance->modifyAspect(original);
}

// ---------------------------------------------------------------------------
// Module
// ---------------------------------------------------------------------------
AspectRatioMod& AspectRatioMod::instance() {
    static AspectRatioMod inst;
    return inst;
}

AspectRatioMod::AspectRatioMod() : mSelf(*ll::mod::NativeMod::current()) {
    g_modInstance = this;
}

float AspectRatioMod::modifyAspect(float originalAspect) const {
    if (!mConfig.enabled) {
        return originalAspect;
    }

    const float ratio = std::clamp(mConfig.ratio, 0.1f, 10.0f);

    switch (static_cast<Mode>(mConfig.mode)) {
        case Mode::Multiplier:
            // Java mod: force aspect = ratio
            return ratio;

        case Mode::Fixed: {
            // Java mod: (height / width) * ratio
            // originalAspect ≈ width/height → invert
            if (originalAspect > 0.001f) {
                const float inv = 1.0f / originalAspect;
                return inv * ratio;
            }
            return ratio;
        }
    }
    return originalAspect;
}

void AspectRatioMod::saveConfigToDisk() {
    if (mConfigFile) {
        mConfigFile->value() = mConfig;
        if (!mConfigFile->save()) {
            getSelf().getLogger().warn("Failed to save config");
        }
    }
}

void AspectRatioMod::registerModMenu() {
    using namespace pl::modmenu;

    ModuleBuilder("aspectratio.main", "Aspect Ratio")
        .description("Change the game's projection aspect ratio (port of the Java AspectRatio mod)")
        .modId("aspectratio")
        .defaultEnabled(mConfig.enabled)
        .onToggle([this](std::string_view /*moduleId*/, bool enabled) {
            mConfig.enabled = enabled;
            saveConfigToDisk();
            getSelf().getLogger().info("Aspect Ratio {}", enabled ? "enabled" : "disabled");
        })
        .onConfigChanged([this](std::string_view /*moduleId*/, std::string_view key,
                                std::string_view value) {
            if (key == "mode") {
                try {
                    int m = std::stoi(std::string(value));
                    mConfig.mode = (m == 1) ? 1 : 0;
                } catch (...) {}
            } else if (key == "ratio") {
                try {
                    mConfig.ratio = std::clamp(std::stof(std::string(value)), 0.1f, 10.0f);
                } catch (...) {}
            }
            saveConfigToDisk();
            getSelf().getLogger().info("Config updated: mode={}, ratio={:.3f}",
                                       mConfig.mode, mConfig.ratio);
        })
        // Mode: Radio (0 = Multiplier, 1 = Fixed)
        .config("mode", "Mode", ConfigType::Radio,
                std::to_string(mConfig.mode),
                "0", "1")
        // Ratio slider 0.1 – 5.0
        .config("ratio", "Ratio", ConfigType::SliderFloat,
                std::to_string(mConfig.ratio),
                "0.1", "5.0")
        .registerModule();
}

bool AspectRatioMod::load() {
    auto& self = getSelf();
    self.getLogger().info("Aspect Ratio mod loading...");

    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    std::filesystem::create_directories(self.getConfigDir(), ec);

    mConfigFile.emplace();
    if (!mConfigFile->load()) {
        self.getLogger().warn("Could not load config – using defaults");
        mConfig = ModConfig{};
    } else {
        mConfig = mConfigFile->value();
    }

    self.getLogger().info("Loaded. enabled={}, mode={}, ratio={:.3f}",
                          mConfig.enabled, mConfig.mode, mConfig.ratio);
    return true;
}

bool AspectRatioMod::enable() {
    auto& self = getSelf();
    self.getLogger().info("Aspect Ratio mod enabling...");

    // Always register the menu so the user can toggle / change settings
    registerModMenu();

    if (mHookInstalled) {
        return true;
    }

    uintptr_t addr = pl::memory::resolveSignature(GET_PERSPECTIVE_PATTERN, "libminecraftpe.so");
    if (addr == 0) {
        self.getLogger().error("Failed to find GetPerspective signature. "
                               "Minecraft version may not be supported (expected ~1.26.44).");
        // Menu still works; hook just won't be active
        return true;
    }

    self.getLogger().info("Found GetPerspective at 0x{:x}", addr);

    g_hookHandle = pl::memory::HookHandle(
        reinterpret_cast<pl::memory::FuncPtr>(addr),
        reinterpret_cast<pl::memory::FuncPtr>(hookedGetPerspective),
        reinterpret_cast<pl::memory::FuncPtr*>(&g_originalGetPerspective),
        pl::memory::HookPriority::Normal
    );

    if (!g_hookHandle.installed()) {
        self.getLogger().error("Failed to install GetPerspective hook");
        return true;
    }

    mHookInstalled = true;
    mOriginalGetPerspective = reinterpret_cast<void*>(g_originalGetPerspective);

    self.getLogger().info("Aspect Ratio hook installed successfully");
    return true;
}

bool AspectRatioMod::disable() {
    auto& self = getSelf();
    self.getLogger().info("Aspect Ratio mod disabling...");
    mConfig.enabled = false;
    saveConfigToDisk();
    pl::modmenu::unregisterModule("aspectratio.main");
    return true;
}

bool AspectRatioMod::unload() {
    getSelf().getLogger().info("Aspect Ratio mod unloading...");
    g_hookHandle.reset();
    pl::modmenu::unregisterModule("aspectratio.main");
    mConfigFile.reset();
    g_modInstance = nullptr;
    return true;
}

} // namespace aspectratio
