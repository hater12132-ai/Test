#pragma once

#include "mod/Config.h"

#include <pl/Config.hpp>
#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <optional>

namespace aspectratio {

class AspectRatioMod {
public:
    static AspectRatioMod& instance();

    AspectRatioMod();

    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

    // Called from the hooked function
    float modifyAspect(float originalAspect) const;

private:
    ll::mod::NativeMod& mSelf;
    ModConfig mConfig;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;

    bool mHookInstalled = false;
    void* mOriginalGetPerspective = nullptr;

    void registerModMenu();
    void saveConfigToDisk();
};

} // namespace aspectratio
