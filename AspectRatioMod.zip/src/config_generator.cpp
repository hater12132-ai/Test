#include "mod/Config.h"

#include <pl/Config.hpp>

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <output_dir>\n";
        return 1;
    }

    std::filesystem::path outDir = argv[1];
    std::error_code ec;
    std::filesystem::create_directories(outDir, ec);

    aspectratio::ModConfig cfg;
    pl::config::ConfigFile<aspectratio::ModConfig> file;
    file.value() = cfg;

    if (!file.save(outDir / "config.json")) {
        std::cerr << "Failed to write config.json\n";
        return 1;
    }

    // Schema is optional but nice for the template
    std::cout << "Generated config in " << outDir << "\n";
    return 0;
}
