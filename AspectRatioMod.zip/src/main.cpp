#include "mod/AspectRatioMod.h"

#include <pl/Mod.hpp>

// Register the mod with Preloader / LeviLauncher
PL_REGISTER_MOD(aspectratio::AspectRatioMod, aspectratio::AspectRatioMod::instance());
