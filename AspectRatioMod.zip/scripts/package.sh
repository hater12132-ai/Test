#!/usr/bin/env bash
set -euo pipefail

# Simple Linux/macOS packaging helper for arm64-v8a
# Requires: Android NDK, CMake, Ninja

ABI="${1:-arm64-v8a}"
NDK="${ANDROID_NDK_HOME:-${ANDROID_HOME:-}/ndk/28.2.13676358}"

if [[ ! -d "$NDK" ]]; then
    echo "Android NDK not found. Set ANDROID_NDK_HOME or ANDROID_HOME"
    exit 1
fi

BUILD_DIR="build-${ABI}"
cmake -S . -B "${BUILD_DIR}" \
    -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="${NDK}/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="${ABI}" \
    -DANDROID_PLATFORM=android-28 \
    -DANDROID_STL=c++_shared \
    -DMOD_ID=aspectratio \
    -DMOD_NAME="Aspect Ratio" \
    -DMOD_AUTHOR="Grok" \
    -DMOD_VERSION=1.0.0 \
    -DMOD_LIBRARY_NAME=aspectratio \
    -DMOD_MINECRAFT_VERSIONS='["1.26.44"]'

cmake --build "${BUILD_DIR}" --target levi_package

echo ""
echo "Done! Look for the .levipack inside ${BUILD_DIR}/"
ls -la "${BUILD_DIR}"/*.levipack 2>/dev/null || true
