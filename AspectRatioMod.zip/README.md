# Aspect Ratio – LeviLauncher Mod (Android arm64)

Standalone port of the Java Fabric mod **AspectRatio**.  
Custom aspect ratio for Minecraft Bedrock **~1.26.44** (arm64-v8a).

## Features

- **Multiplier** mode → `aspect = ratio`
- **Fixed** mode → `aspect = (height / width) * ratio` (same as the Java mod)
- In-game **Mod Menu** (toggle + mode + ratio slider)
- Persistent config

## Get the .levipack (easiest – GitHub Actions)

1. Create a new GitHub repository (public is fine).
2. Upload everything from this project (or push the zip contents).
3. Go to the **Actions** tab → select **Build Aspect Ratio levipack** → **Run workflow**.
4. When it finishes, open the run → **Artifacts** → download  
   `aspectratio-1.0.0-arm64-v8a`.
5. Unzip the artifact → you get the `.levipack`.
6. Import it in LeviLauncher → enable → launch Minecraft.

You can also just push to `main` / `master` and the workflow runs automatically.

## Local build (optional)

```bash
export ANDROID_NDK_HOME=/path/to/ndk/r28c
./scripts/package.sh arm64-v8a
```

## Menu controls

| Control | Description |
|---------|-------------|
| Toggle  | Enable / disable |
| Mode    | 0 = Multiplier, 1 = Fixed |
| Ratio   | Slider 0.1 – 5.0 |

## Config file

```
.../mods/aspectratio/config/config.json
```

```json
{
  "version": 1,
  "enabled": true,
  "mode": 0,
  "ratio": 1.777
}
```

Examples: `1.777` ≈ 16:9 · `1.333` ≈ 4:3 · `2.37` ≈ ultrawide

## Notes

- Signature is for ~1.26.44 arm64. Future game updates may break the hook.
- Client-side visual only.
- Public servers (Hive, Zeqa, etc.) may flag client mods – use at your own risk.

## License

GPL-3.0
